#ifndef _FLAG_H_
# define _FLAG_H_
#include "global.h"
#include <stdint.h>
void	flag_init(void);
void	set_flag(uint8_t);
# define UP 15
# define RIGHT 23
# define LEFT 6
#endif
